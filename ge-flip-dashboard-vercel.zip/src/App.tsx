import { useMemo, useState } from "react";
import { useLatest } from "./hooks/useLatest";
import { useMapping } from "./hooks/useMapping";
import type { MappingItem } from "./lib/types";

function formatGp(n: number): string {
  if (!Number.isFinite(n)) return "-";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}m`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return `${n}`;
}

export default function App() {
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<MappingItem | null>(null);

  const mapping = useMapping();
  const latest = useLatest();

  const candidates = useMemo(() => {
    const items = mapping.data ?? [];
    const query = q.trim().toLowerCase();
    if (!query) return items.slice(0, 20);
    return items
      .filter((it) => it.name.toLowerCase().includes(query))
      .slice(0, 20);
  }, [mapping.data, q]);

  const latestEntry = selected ? latest.data?.data?.[String(selected.id)] : undefined;
  const margin = latestEntry ? latestEntry.high - latestEntry.low : undefined;
  const roi = latestEntry && latestEntry.low > 0 ? (margin! / latestEntry.low) * 100 : undefined;

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-5xl px-4 py-6">
        <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">GE Flip Dashboard</h1>
            <p className="text-sm text-zinc-400">
              Live OSRS Wiki prices via serverless proxy
            </p>
          </div>

          <div className="text-xs text-zinc-400">
            {latest.isFetching ? "Updating…" : "Live"}
          </div>
        </header>

        <div className="mt-6 grid gap-4 md:grid-cols-5">
          <section className="md:col-span-2 rounded-xl border border-zinc-800 bg-zinc-900/40 p-4">
            <label className="text-sm font-medium">Search item</label>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="e.g. ranaar, dragon bones…"
              className="mt-2 w-full rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-500"
            />

            <div className="mt-3">
              {mapping.isLoading ? (
                <div className="text-sm text-zinc-400">Loading mapping…</div>
              ) : mapping.isError ? (
                <div className="text-sm text-red-300">
                  Failed to load mapping. (Check Vercel env var <code>WIKI_UA</code>)
                </div>
              ) : (
                <ul className="max-h-80 overflow-auto rounded-lg border border-zinc-800">
                  {candidates.map((it) => (
                    <li key={it.id}>
                      <button
                        onClick={() => setSelected(it)}
                        className={
                          "flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-zinc-800/60 " +
                          (selected?.id === it.id ? "bg-zinc-800/60" : "")
                        }
                      >
                        <span className="truncate">{it.name}</span>
                        <span className="ml-3 text-xs text-zinc-400">#{it.id}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          <section className="md:col-span-3 rounded-xl border border-zinc-800 bg-zinc-900/40 p-4">
            <h2 className="text-sm font-medium">Selected item</h2>

            {!selected ? (
              <div className="mt-3 text-sm text-zinc-400">Pick an item from the list.</div>
            ) : latest.isError ? (
              <div className="mt-3 text-sm text-red-300">
                Failed to load latest prices. (Proxy / User-Agent issue)
              </div>
            ) : !latestEntry ? (
              <div className="mt-3 text-sm text-zinc-400">No latest price data for this item yet.</div>
            ) : (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
                  <div className="text-xs text-zinc-400">Low (buy)</div>
                  <div className="mt-1 text-xl font-semibold">{formatGp(latestEntry.low)} gp</div>
                </div>
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
                  <div className="text-xs text-zinc-400">High (sell)</div>
                  <div className="mt-1 text-xl font-semibold">{formatGp(latestEntry.high)} gp</div>
                </div>
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
                  <div className="text-xs text-zinc-400">Margin</div>
                  <div className="mt-1 text-xl font-semibold">{formatGp(margin ?? NaN)} gp</div>
                </div>
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
                  <div className="text-xs text-zinc-400">ROI</div>
                  <div className="mt-1 text-xl font-semibold">{roi ? `${roi.toFixed(2)}%` : "-"}</div>
                </div>

                <div className="sm:col-span-2 mt-2 rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-xs text-zinc-400">
                  Tip: next step is pulling <code>/api/wiki/timeseries</code> for a chart and
                  <code>/api/wiki/1h</code> or <code>/api/wiki/5m</code> for volume-weighted “Hot Flips”.
                </div>
              </div>
            )}
          </section>
        </div>

        <footer className="mt-8 text-xs text-zinc-500">
          If you see errors: set <code>WIKI_UA</code> in Vercel env vars to something descriptive (required by the Wiki).
        </footer>
      </div>
    </div>
  );
}
