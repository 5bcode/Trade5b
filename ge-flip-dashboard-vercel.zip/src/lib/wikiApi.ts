import type { LatestResponse, MappingResponse } from "./types";

async function fetchJson<T>(path: string): Promise<T> {
  const r = await fetch(path, { headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json() as Promise<T>;
}

// Calls your Vercel serverless proxy (same-origin)
export const wikiApi = {
  mapping: () => fetchJson<MappingResponse>("/api/wiki/mapping"),
  latest: () => fetchJson<LatestResponse>("/api/wiki/latest"),
};
