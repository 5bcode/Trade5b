export type MappingItem = {
  id: number;
  name: string;
  limit?: number;
  examine?: string;
  members?: boolean;
  lowalch?: number;
  highalch?: number;
  icon?: string;
};

export type LatestEntry = {
  high: number;
  highTime: number;
  low: number;
  lowTime: number;
};

export type LatestResponse = {
  data: Record<string, LatestEntry>;
};

export type MappingResponse = MappingItem[];
