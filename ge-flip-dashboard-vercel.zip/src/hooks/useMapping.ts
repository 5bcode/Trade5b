import { useQuery } from "@tanstack/react-query";
import { wikiApi } from "../lib/wikiApi";

export function useMapping() {
  return useQuery({
    queryKey: ["mapping"],
    queryFn: wikiApi.mapping,
    staleTime: 24 * 60 * 60_000,
  });
}
