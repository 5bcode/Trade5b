import { useQuery } from "@tanstack/react-query";
import { wikiApi } from "../lib/wikiApi";

export function useLatest() {
  return useQuery({
    queryKey: ["latest"],
    queryFn: wikiApi.latest,
    staleTime: 15_000,
    refetchInterval: 15_000,
  });
}
